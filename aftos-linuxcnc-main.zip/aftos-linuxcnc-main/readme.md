This repository stores the AXIS GUI configuration for LinuxCNC

LinuxCNC is already installed and setup on the raspberry pi, this repo is for refrence only.

https://www.linuxcnc.org/iso/linuxcnc-2.8.1-pi4.zip

https://gist.github.com/Bouni/8b4532d0bdf012bd83c65d3eb62f8aa2

The Pi currently has a NAT firwall rule to allow traffic coming via USB NIC to share the wlan0 interface's wifi connection.

connect to the linuxcnc by connection to rdp `10.0.0.2`  with  user `pi` password `deepvision` while connected to the USB ethernet port and using a IP on your computer such as `10.0.0.3/24`

To start linuxcnc as currently installed on the pi open a terminal 

```bash
cd linuxcnc/configs/sim.axis/
linuxcnc corexy.ini
```

This will popup the linuxcnc axis gui and start the linuxcncrsh session for `aftos_cli.py` to hook onto. 