The following instructions assume a native Linux environment running on Ubuntu 22.04 Jammy. ROS2 Humble does not have a build for earlier version of Ubuntu.

When installing packages on a Ubuntu derivative (Linux Mint, etc), the following flag may be required: --os=ubuntu:jammy

Ethercat Master for Linux install instructions: https://etherlab.org/en/ethercat/
    Ethercat master files are available in this repo: ethercat-master.zip

Install ROS2 Humble using the following guide: https://docs.ros.org/en/humble/Installation.html
    ROS2 expects Ubuntu, the ROS2 steps are most likely to require -os=ubuntu:jammy
    ROS2 installation files are distribution dependent and are best sourced from the appropriate package repository

Install ROS2 Ethercat Driver using the following guide: https://github.com/ICube-Robotics/ethercat_driver_ros2/blob/main/INSTALL.md
    ROS2 Ethercat Driver files are available in this repo: ethercat_driver_ros2-main.zip

Configure the Ethercat master in the file ethercat.conf usually found in /usr/local/etherlab/etc to have the MAC address of the local NIC on the eth0 interface used to connect to the Ethercat slaves.

When connected to the first slave in the chain, Ethercat can be started using "ethercat start", slaves can be viewed using ethercat slaves. Refer to the documentation for more information.

Create the ROS2 workspace using the following guide: https://docs.ros.org/en/humble/Tutorials/Beginner-Client-Libraries/Creating-A-Workspace/Creating-A-Workspace.html
    Start the workspace with ros2 run

